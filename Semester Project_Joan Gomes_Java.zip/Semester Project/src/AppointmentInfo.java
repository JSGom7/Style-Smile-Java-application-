public class AppointmentInfo extends UserInfo {
	
	private String Day;
	private String Time;
	private String ServiceDesired;
	private String StylistDesired;
	private double Subtotal;
	private double TipPercent;
	private double TipTotal;
	private double TotalCost;
	
	
	/** Construct a default appointment object **/
	public AppointmentInfo() {
		 
	 }
	 
	 /** Construct a user object with the specified Day, Time, ServiceDesired, StylistDesired **/
	 public AppointmentInfo (String Day, String Time, String ServiceDesired, String StylistDesired) {
		 
		 this.Day = Day;
		 this.Time = Time;
		 this.ServiceDesired = ServiceDesired;
		 this.StylistDesired = StylistDesired;
	 }
	 
	 /** Return Day **/
     public String getDay () {
		 
		 return Day;
	 }
     
     /** Set a new Day **/ 
	 public void setDay(String Day) {
		 
		 this.Day = Day;
	 }
	 
	 /** Return Time **/
     public String getTime () {
		 
		 return Time;
	 }
     
     /** Set a new Time **/ 
	 public void setTime(String Time) {
		 
		 this.Time = Time;
	 }
	 
	 /** Return ServiceDesired **/
	 public String getServiceDesired () {
		 
		 return ServiceDesired;
	 }
	 
	 /** Set a new ServiceDesired  **/ 
	 public void setServiceDesired(String ServiceDesired) {
		 
		 this.ServiceDesired = ServiceDesired;
	 }
	 
	 /** Return StylistDesired **/
	 public String getStylistDesired () {
		 
		 return StylistDesired;
	 }
	 
	 /** Set a new StylistDesired **/ 
	 public void setStylistDesired(String StylistDesired) {
		 
		 this.StylistDesired = StylistDesired;
	 }
	 
	 /** Return Subtotal **/
	 public double getSubtotal () {
		 
		return Subtotal;
	 }
	 
	 /** Set a new Subtotal **/ 
	 public void setSubtotal(double Subtotal) {
		 
		 this.Subtotal = Subtotal;
	 }
	 
	 /** Return TipPercent **/
	 public double getTipPercent () {
		 
		 return TipPercent;
	 }
	 
	 /** Set a new TipPercent **/ 
	 public void setTipPercent(double TipPercent) {
		 
		 this.TipPercent = TipPercent;
	 }
	 
	 /** Return TipTotal **/
	 public double getTipTotal (double Subtotal, double TipPercent) {
		 
		 return Subtotal * (TipPercent / 100);
	 }
	 
	 /** Return TotalCost **/
	 public double getTotalCost (double Subtotal, double TipTotal) {
		 
		return Subtotal + TipTotal;
}
	 
	 
}
