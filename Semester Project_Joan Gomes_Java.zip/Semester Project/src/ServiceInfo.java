public abstract class ServiceInfo {
	
	 private String ServiceOffered;
	 private String StylistOffered;
	 private String DayAvailable;
	 private String TimeAvailable;
	 
	 
	 /** Construct a default service object **/ 
	 public ServiceInfo() {
		 
	 }
	 
	 /** Construct a user object with the specified ServiceOffered, StylistOffered, DayAvailable, TimeAvailable **/
	 public ServiceInfo (String ServiceOffered, String StylistOffered, String DayAvailable, String TimeAvailable) {
		 
		 this.ServiceOffered = ServiceOffered;
		 this.StylistOffered = StylistOffered;
		 this.DayAvailable = DayAvailable;
		 this.TimeAvailable = TimeAvailable;
		 
	 }
	 	
	 /** Abstract method getServiceOffered **/
	 public abstract String getServiceOffered ();
	 
	 /** Abstract method getStylistOffered **/
	 public abstract String getStylistOffered ();
	 
	 /** Abstract method getDayAvailable **/
	 public abstract String getDayAvailable ();
	 
	 /** Abstract method getTimeAvailable **/
	 public abstract String getTimeAvailable ();
	 
	 
}
