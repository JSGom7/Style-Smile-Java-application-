public class UserInfo {
	
	 private String FirstName;
	 private String LastName;
	 private String Email;
	 private String Phone; 
	 
	 
	 /** Construct a default user object **/ 
	 public UserInfo() {
		 
	 }
	 
	 /** Construct a user object with the specified FirstName, LastName, Email, Phone **/
	 public UserInfo (String FirstName, String LastName, String Email, String Phone) {
		 
		 this.FirstName = FirstName;
		 this.LastName = LastName;
		 this.Email = Email;
		 this.Phone = Phone;
	 }
	 
	 /** Return FirstName **/
	 public String getFirstName () {
		 
		 return FirstName;
	 }
	 
	 /** Set a new FirstName **/ 
	 public void setFirstName(String FirstName) {
		 
		 this.FirstName = FirstName;
	 }
	 
	 /** Return LastName **/
	 public String getLastName () {
		 
		 return LastName;
	 }
	 
	 /** Set a new LastName **/ 
	 public void setLastName(String LastName) {
		 
		 this.LastName = LastName;
	 }
	
	 /** Return Email **/
	 public String getEmail () {
		 
		 return Email;
	 }
	 
	 /** Set a new Email **/ 
	 public void setEmail(String Email) {
		 
		 this.Email = Email;
	 }
	 
	 /** Return Phone **/
	 public String getPhone () {
		 
		 return Phone;
	 }
	 
	 /** Set a new Phone **/ 
	 public void setPhone(String Phone) {
		 
		 this.Phone = Phone;
	 }
	 
	 /** Return a string representation of this object */
	 public String toString() {
		 
		 return "First Name: " + FirstName + "\nLast Name: " + LastName +
				 "\nEmail: " + Email + "\nPhone: " + Phone ;
		      }



}
