import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.input.KeyCode;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserInterface extends Application {
	
	protected TextField tfFirstName = new TextField();
	protected TextField tfLastName = new TextField();
	protected TextField tfEmail = new TextField();
	protected TextField tfPhone = new TextField();
	protected TextField tfSubtotal = new TextField();
	protected TextField tfTipPercent = new TextField();
	protected TextField tfTipTotal = new TextField();
	protected TextField tfTotalCost = new TextField();
	
	protected ComboBox<String> cbDay = new ComboBox<>();
	protected ComboBox<String> cbTime = new ComboBox<>();
	protected ComboBox<String> cbService = new ComboBox<>();
	protected ComboBox<String> cbStylist = new ComboBox<>();
	
	protected Button btConfirm= new Button("Confirm Appointment");
	protected Button btSubmit= new Button("Submit");
	
	 private String[] Service = {"Express Haircut - $16", "Haircut and Shampoo - $19", 
				"Haircut, Shampoo and Style - $35", "Color - $45", "Style - $27", "Waxing - $10"};
	 
	 ObservableList<String> items =  FXCollections.observableArrayList(Service); 

	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		
		// Set text field preferences
		tfFirstName.setAlignment(Pos.BOTTOM_RIGHT);
		tfLastName.setAlignment(Pos.BOTTOM_RIGHT);
		tfEmail.setAlignment(Pos.BOTTOM_RIGHT);
		tfPhone.setAlignment(Pos.BOTTOM_RIGHT);
		tfSubtotal.setAlignment(Pos.BOTTOM_RIGHT);
		tfTipPercent.setAlignment(Pos.BOTTOM_RIGHT);
		tfTipTotal.setAlignment(Pos.BOTTOM_RIGHT);
		tfTotalCost.setAlignment(Pos.BOTTOM_RIGHT);
		
		btConfirm.setAlignment(Pos.BOTTOM_RIGHT);
		btSubmit.setAlignment(Pos.BOTTOM_RIGHT);
		
		cbDay.getItems().addAll("Monday", "Tuesday", "Wednesday", "Thursday", "Friday");
		cbDay.setValue("Monday");
		cbTime.getItems().addAll("8am", "9am", "10am", "1pm", "2pm", "3pm");
		cbTime.setValue("8am");
		cbService.getItems().addAll(Service);
		cbService.setValue("Express Haircut - $16");
		cbStylist.getItems().addAll("First Available", "Nancy", "Beth", "Victor");
		cbStylist.setValue("First Available");
		

		// Create a grid pane and add nodes to it
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setHgap(10);
		pane.setVgap(2);
		
		pane.add(new Label("First Name:"), 0, 0);
		pane.add(tfFirstName, 1, 0);
		pane.add(new Label("Last Name:"), 0, 1);
		pane.add(tfLastName, 1, 1);
		pane.add(new Label("Email:"), 0, 2);
		pane.add(tfEmail, 1, 2);
		pane.add(new Label("Phone:"), 0, 3);
		pane.add(tfPhone, 1, 3);
		pane.add(new Label("Day:"), 0, 4);
		pane.add(cbDay, 1, 4);
		pane.add(new Label("Time:"), 0, 5);
		pane.add(cbTime, 1, 5);
		pane.add(new Label("Service Desired:"), 0, 6);
		pane.add(cbService, 1, 6);
		pane.add(new Label("Stylist Desired:"), 0, 7);
		pane.add(cbStylist, 1, 7);
		pane.add(btSubmit,1,15);
		pane.add(new Label("Subtotal:"), 0, 23);
		pane.add(tfSubtotal, 1, 23);
		pane.add(new Label("Tip Percent (%):"), 0, 24);
		pane.add(tfTipPercent, 1, 24);
		pane.add(new Label("Tip Total:"), 0, 25);
		pane.add(tfTipTotal, 1, 25);
		pane.add(new Label("Total Cost:"), 0, 26);
		pane.add(tfTotalCost, 1, 26);
		pane.add(btConfirm,1,34);
	
		
		
		// Create and register handler
		
		btSubmit.setOnAction(e -> setSubtotal(items.indexOf(cbService.getValue())));
		
		tfTipPercent.setOnKeyPressed(e -> {
			if (e.getCode() == KeyCode.ENTER &&
				tfTipPercent.getText().length() > 0) {
				double TipPercent = Double.parseDouble(tfTipPercent.getText());
				double Subtotal = Double.parseDouble(tfSubtotal.getText()); 
				tfTipTotal.setText(String.format("%.2f", (Subtotal*(TipPercent /100))));
				double TipTotal = Double.parseDouble(tfTipTotal.getText());
				tfTotalCost.setText("$" + String.format("%.2f",(Subtotal+TipTotal)));
			}
		});
		
		btConfirm.setOnAction(e -> {
			 Platform.exit();
			 System.out.println("Thanks for making appointment with Style & Smile!");
		});
		
		
		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 400, 500);
		primaryStage.setTitle("Style & Smile"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	
	}
	
	
	//Method for setting Subtotal 
	 public void setSubtotal(int index) {
		 if (index == 0)
			 tfSubtotal.setText(String.valueOf(16.0));
		 else if (index == 1)
			 tfSubtotal.setText(String.valueOf(19.0));
		 else if (index == 2)
			 tfSubtotal.setText(String.valueOf(35.0));
		 else if (index == 3)
			 tfSubtotal.setText(String.valueOf(45.0));
		 else if (index == 4)
			 tfSubtotal.setText(String.valueOf(27.0));
		 else if (index == 5)
			 tfSubtotal.setText(String.valueOf(10.0));
             
             }
	
	 public static void main(String[] args) {
	        Application.launch(args);

	    }

}
