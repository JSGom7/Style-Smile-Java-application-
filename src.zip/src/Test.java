public class Test {

	public static void main(String[] args) {
		
		/** UserInfo object **/
		UserInfo user = new UserInfo("Joan", "Gomes", "abc@bol.com", "123456789");
		
		/** Invoke First Name **/
		System.out.println("First Name: " + user.getFirstName() );
		
		/** Invoke Last Name **/
		System.out.println("Last Name: " + user.getLastName());
		
		/** Invoke Email **/
		System.out.println("Email: " + user.getEmail());
		
		/** Invoke Phone **/
		System.out.println("Phone: " + user.getPhone());
		
		
		/** AppointmentInfo object **/
		AppointmentInfo appointment = new AppointmentInfo("Monday", "2:30pm", "Haircut & Shampoo", "Becky");
		
		/** Invoke Day **/
		System.out.println("Day: " + appointment.getDay());
		
		/** Invoke Time **/
		System.out.println("Time: "  + appointment.getTime());
		
		/** Invoke Service Desired **/
		System.out.println("Service Desired: " + appointment.getServiceDesired());
		
		/** Invoke Stylist Desired **/
		System.out.println("Stylist Desired: " + appointment.getStylistDesired());
		
		/** Set Subtotal **/ 
		appointment.setSubtotal(23.39);
		
		/** Invoke Subtotal  **/
		double Subtotal = appointment.getSubtotal();
		System.out.println("Subtotal: $" + Subtotal );
		
		/** Set Tip Percent **/ 
		appointment.setTipPercent(10);
		
		/** Invoke Tip Percent  **/
		System.out.println("Tip Percent: " + appointment.getTipPercent() + "%");
		
		/** Invoke TipTotal **/ 
		double TipTotal = appointment.getTipTotal(Subtotal, appointment.getTipPercent());
		System.out.println("Tiptotal: $" + TipTotal );
		
		/** Invoke Total Cost **/
		System.out.println("Total Cost: $" + appointment.getTotalCost(Subtotal, TipTotal));
	}

}
